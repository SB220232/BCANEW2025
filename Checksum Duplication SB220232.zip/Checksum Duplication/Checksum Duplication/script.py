import os
import hashlib
from tkinter import Tk, filedialog, Button, Listbox, Scrollbar, END, messagebox


# Function to calculate MD5 checksum of a file
def calculate_md5(file_path, chunk_size=1024):
    hash_md5 = hashlib.md5()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except Exception as e:
        return None


# Function to find duplicate files in a directory
def find_duplicates(directory):
    file_hashes = {}
    duplicates = []

    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_hash = calculate_md5(file_path)

            if file_hash:
                if file_hash in file_hashes:
                    duplicates.append((file_path, file_hashes[file_hash], file_hash))
                else:
                    file_hashes[file_hash] = file_path
    return duplicates


# GUI Application Class
class DuplicateFileFinderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Duplicate File Finder with Checksums")
        self.root.geometry("700x500")

        # Buttons
        self.select_dir_button = Button(root, text="Select Directory", command=self.select_directory)
        self.select_dir_button.pack(pady=10)

        self.find_duplicates_button = Button(root, text="Find Duplicates", command=self.display_duplicates)
        self.find_duplicates_button.pack(pady=10)

        # Listbox with Scrollbar
        self.scrollbar = Scrollbar(root)
        self.scrollbar.pack(side="right", fill="y")

        self.duplicates_listbox = Listbox(root, yscrollcommand=self.scrollbar.set, width=100, height=25)
        self.duplicates_listbox.pack(pady=10)

        self.scrollbar.config(command=self.duplicates_listbox.yview)

        # Variables
        self.selected_directory = None
        self.duplicates = []

    def select_directory(self):
        """Open a dialog to select a directory."""
        self.selected_directory = filedialog.askdirectory()
        if not self.selected_directory:
            messagebox.showwarning("Warning", "No directory selected!")

    def display_duplicates(self):
        """Find and display duplicate files along with their checksums."""
        if not self.selected_directory:
            messagebox.showerror("Error", "Please select a directory first!")
            return

        # Clear previous results
        self.duplicates_listbox.delete(0, END)

        # Find duplicates
        self.duplicates = find_duplicates(self.selected_directory)

        if not self.duplicates:
            messagebox.showinfo("Info", "No duplicate files found!")
            return

        # Display duplicates in the listbox with checksums
        for dup in self.duplicates:
            duplicate_file, original_file, checksum = dup
            self.duplicates_listbox.insert(END, f"Checksum: {checksum}")
            self.duplicates_listbox.insert(END, f"Duplicate: {original_file}")
            self.duplicates_listbox.insert(END, f"Original: {duplicate_file}")
            self.duplicates_listbox.insert(END, "-" * 80)


# Main Function to Run the App
if __name__ == "__main__":
    root = Tk()
    app = DuplicateFileFinderApp(root)
    root.mainloop()
